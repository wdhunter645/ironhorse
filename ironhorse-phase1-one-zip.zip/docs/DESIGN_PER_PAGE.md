# Design — Per Page (Phase‑1)

Public Home: hero, weekly vote, card+join/login, charities, milestones, Q&A+news, unified calendar.
Member Area: login/signup, card, posts, comments, upload media.
Admin: moderation, reports/logs, schedule view.
