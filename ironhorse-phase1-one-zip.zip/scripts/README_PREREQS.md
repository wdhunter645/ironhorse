# Prereqs
See order: setup_supabase_project.sh → env.sample → check_env.sh → set_repo_secrets.sh → set_vercel_env.sh → db_apply.sh → verify_b2.sh → health_smoke.sh
