import { NextResponse } from "next/server";

type CheckResult = { ok: boolean; note?: string };

async function checkRoute(urlPath: string): Promise<CheckResult> {
  try {
    const res = await fetch(new URL(urlPath, process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"), { cache: "no-store" });
    if (res.status === 200) return { ok: true };
    return { ok: false, note: `HTTP ${res.status}` };
  } catch (e:any) {
    return { ok: false, note: String(e?.message || e) };
  }
}

function envPresence(keys: string[]) {
  const present: string[] = [];
  const missing: string[] = [];
  for (const k of keys) {
    if (process.env[k]) present.push(k);
    else missing.push(k);
  }
  return { present, missing };
}

async function checkSupabaseTables(expected: string[]) {
  const haveAdmin = !!process.env.SUPABASE_SERVICE_ROLE_KEY && !!process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!haveAdmin) {
    return { ok: false, note: "Missing SUPABASE_SERVICE_ROLE_KEY or NEXT_PUBLIC_SUPABASE_URL", tables: expected.map(n => ({ name: n, ok: false, note: "env" })) };
  }
  try {
    const { createClient } = await import("@supabase/supabase-js");
    const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } });
    const results: any[] = [];
    let allOk = true;
    for (const name of expected) {
      const { error } = await supabase.from(name).select("id", { count: "exact", head: true }).limit(1);
      if (error) {
        const msg = (error as any)?.message || String(error);
        results.push({ name, ok: false, note: msg });
        allOk = false;
      } else {
        results.push({ name, ok: true });
      }
    }
    return { ok: allOk, tables: results };
  } catch (e:any) {
    return { ok: false, note: "supabase-js not available or failed to init", error: String(e?.message || e), tables: expected.map(n => ({ name: n, ok: false, note: "client" })) };
  }
}

export async function GET() {
  const envCore = envPresence([
    "NEXT_PUBLIC_SUPABASE_URL",
    "NEXT_PUBLIC_SUPABASE_ANON_KEY",
    "SUPABASE_SERVICE_ROLE_KEY",
    "ADMIN_EMAILS",
  ]);
  const envB2 = envPresence([
    "B2_KEY_ID",
    "B2_APP_KEY",
    "B2_BUCKET",
    "B2_ENDPOINT",
    "PUBLIC_B2_BASE_URL",
  ]);
  const envSite = envPresence([ "NEXT_PUBLIC_SITE_URL" ]);

  const routes = {
    quotesWeekly: await checkRoute("/api/quotes/weekly"),
    vote: await checkRoute("/api/vote"),
    b2Presign: await checkRoute("/api/admin/b2/presign"),
  };

  const tables = await checkSupabaseTables([
    "media_assets", "quotes", "photos", "matchups", "votes", 
    "charities", "milestones", "posts", "events"
  ]);

  const ok = (
    envCore.missing.length === 0 &&
    envB2.missing.length === 0 &&
    envSite.missing.length === 0 &&
    routes.quotesWeekly.ok &&
    routes.vote.ok &&
    routes.b2Presign.ok &&
    tables.ok
  );

  const body = {
    ok,
    env: {
      core: envCore,
      b2: envB2,
      site: envSite,
    },
    routes,
    tables,
    generatedAt: new Date().toISOString(),
  };

  return NextResponse.json(body, { status: ok ? 200 : 200 });
}