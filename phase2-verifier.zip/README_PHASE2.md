# Phase 2 Verification Pack (Non‑destructive)

This pack adds a small diagnostics API and a Node verifier to **confirm** the Phase‑2 deliverables on your **live Vercel site**, without relying on Copilot/Codex heuristics.

> It does **not** create/alter tables. It only checks presence and returns a status report.

## What it checks

- **Environment**
  - `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_EMAILS`
  - `B2_KEY_ID`, `B2_APP_KEY`, `B2_BUCKET`, `B2_ENDPOINT`, `PUBLIC_B2_BASE_URL`
  - `NEXT_PUBLIC_SITE_URL`

- **Routes**
  - `/api/quotes/weekly` returns `200`
  - `/api/vote` returns `200`
  - `/api/admin/b2/presign` returns `200`

- **Supabase tables** (via a harmless `select` probe)
  - `media_assets`, `quotes`, `photos`, `matchups`, `votes`, `charities`, `milestones`, `posts`, `events`

## How to use

1. **Unzip at repo root**, commit, and push to `main`. Vercel will deploy.
2. Ensure your production env has the keys listed above.
3. From your laptop (or Codespaces shell), run:

```bash
# Node 20+ recommended
SITE_URL="https://your-prod.vercel.app" node scripts/phase2/verify.js
```

This writes two files:

- `reports/phase2/phase2-status.json` – machine‑readable details
- `reports/phase2/phase2-report.md` – human report you can paste into issues/PRs

## Interpreting results

- If **env** is missing entries, fix them in Vercel → Settings → Environment Variables.
- If **routes** fail, implement the missing endpoint(s) per the approved plan.
- If **tables** are missing, run your **idempotent migrations** (Phase‑2 task) and rerun the verifier.

## Removal

Once verified, you can remove the `app/api/phase2/status` folder.