/**
 * Phase-2 verifier (remote).
 * Usage:
 *   SITE_URL="https://your-prod.vercel.app" node scripts/phase2/verify.js
 * Outputs:
 *   reports/phase2/phase2-status.json
 *   reports/phase2/phase2-report.md
 */
const fs = require("fs");
const path = require("path");

const SITE = process.env.SITE_URL || process.env.NEXT_PUBLIC_SITE_URL;
if (!SITE) {
  console.error("❌ Set SITE_URL to your live site, e.g. https://ironhorse-prod.vercel.app");
  process.exit(1);
}

const OUT = path.join(process.cwd(), "reports", "phase2");
fs.mkdirSync(OUT, { recursive: true });

(async () => {
  const url = `${SITE.replace(/\/+$/,"")}/api/phase2/status`;
  const res = await fetch(url, { cache: "no-store" });
  const data = await res.json();

  fs.writeFileSync(path.join(OUT, "phase2-status.json"), JSON.stringify(data, null, 2));

  const lines = [];
  function section(h){ lines.push("", `## ${h}`, ""); }
  function kv(k,v){ lines.push(`- **${k}:** ${v}`); }
  function badge(ok){ return ok ? "✅" : "❌"; }

  lines.push(`# Phase 2 Verification Report`);
  kv("Site", SITE);
  kv("Generated", new Date().toISOString());

  section("Environment");
  kv("Core env", `${badge(data.env.core.missing.length===0)} present: ${data.env.core.present.join(", ")||"(none)"}, missing: ${data.env.core.missing.join(", ")||"(none)"}`);
  kv("B2 env", `${badge(data.env.b2.missing.length===0)} present: ${data.env.b2.present.join(", ")||"(none)"}, missing: ${data.env.b2.missing.join(", ")||"(none)"}`);
  kv("Site env", `${badge(data.env.site.missing.length===0)} present: ${data.env.site.present.join(", ")||"(none)"}, missing: ${data.env.site.missing.join(", ")||"(none)"}`);

  section("Routes");
  for (const [name, r] of Object.entries(data.routes)) {
    kv(name, `${badge(r.ok)} ${r.ok ? "OK" : (r.note || "not responding 200")}`);
  }

  section("Tables");
  if (data.tables?.tables) {
    data.tables.tables.forEach((t) => kv(t.name, `${badge(t.ok)} ${t.note||""}`));
  } else {
    kv("tables", "unable to query (missing env or supabase-js)");
  }

  section("Summary");
  kv("Overall", badge(data.ok));

  fs.writeFileSync(path.join(OUT, "phase2-report.md"), lines.join("\n"));

  console.log(`\n✅ Wrote:\n  - ${path.join(OUT,"phase2-status.json")}\n  - ${path.join(OUT,"phase2-report.md")}\n`);
})().catch((err) => {
  console.error("Verifier failed:", err);
  process.exit(1);
});