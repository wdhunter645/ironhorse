
'use client';
import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { href: "/weekly", label: "Weekly Matchup" },
  { href: "/milestones", label: "Milestones" },
  { href: "/charities", label: "Charities" },
  { href: "/news", label: "News & Q&A" },
  { href: "/calendar", label: "Calendar" },
  { href: "/member", label: "Join" },
];

export default function Header(){
  const pathname = usePathname();
  return (
    <nav className=\"nav\">
      <Link className=\"brand\" href="/">Lou Gehrig Fan Club</Link>
      <span className=\"spacer\" />
      {links.map(l => (
        <Link
          key={l.href}
          href={l.href}
          style={{opacity: pathname?.startsWith(l.href) ? 1 : .85, fontWeight: pathname?.startsWith(l.href) ? 700 : 500 }}
        >
          {l.label}
        </Link>
      ))}
    </nav>
  )
}
