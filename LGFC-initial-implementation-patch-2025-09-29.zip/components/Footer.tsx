
import Link from "next/link";

export default function Footer(){
  return (
    <div style={{display:'flex', gap:16, justifyContent:'center', flexWrap:'wrap'}}>
      <Link href="/privacy">Privacy</Link>
      <Link href="/terms">Terms</Link>
      <Link href="/admin">Admin</Link>
      <span className="small">© {new Date().getFullYear()} Lou Gehrig Fan Club</span>
    </div>
  )
}
