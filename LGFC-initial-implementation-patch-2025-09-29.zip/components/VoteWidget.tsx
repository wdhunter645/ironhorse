
'use client';
import { useEffect, useState } from "react";

type Choice = 'a' | 'b' | null;

export default function VoteWidget(){
  const [choice, setChoice] = useState<Choice>(null);

  useEffect(() => {
    try {
      const v = localStorage.getItem('weeklyVote');
      if (v === 'a' || v === 'b') setChoice(v);
    } catch {}
  }, []);

  const vote = (c: Choice) => {
    if (!c) return;
    try { localStorage.setItem('weeklyVote', c); } catch {}
    setChoice(c);
  };

  return (
    <div className="hero">
      <h2 className="h1">Weekly Matchup</h2>
      <p className="p">Pick your favorite photo for this week’s matchup. (Local-only demo — no account required.)</p>
      <div className="grid2">
        <div className="card">
          <img src="/images/lou1.svg" alt="Lou Gehrig option A" />
          <div className="center" style={{marginTop:12}}>
            <button className="btn" onClick={()=>vote('a')} disabled={!!choice}>
              {choice === 'a' ? 'Voted ✓' : 'Vote A'}
            </button>
          </div>
        </div>
        <div className="card">
          <img src="/images/lou2.svg" alt="Lou Gehrig option B" />
          <div className="center" style={{marginTop:12}}>
            <button className="btn" onClick={()=>vote('b')} disabled={!!choice}>
              {choice === 'b' ? 'Voted ✓' : 'Vote B'}
            </button>
          </div>
        </div>
      </div>
      {choice && <p className="p" style={{marginTop:12}}>Thanks for voting. You can change your pick by clearing site data.</p>}
    </div>
  )
}
