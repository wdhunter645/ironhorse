
# Initial Implementation Patch (Drop-in)

This patch gives you a **working, dependency-free** site shell with the required LGFC navigation and the home **hero + 2-photo weekly vote** UI. No Supabase, no B2, no workflows required.

## What to do
1. Unzip at the repo root, allowing it to **overwrite** existing files under `app/` and `components/` and add `public/images/`.
2. Commit and push to your trunk (`feat/homepage-layout-v1`). Vercel will build and the site will render.

## What you get
- Exact header nav: Weekly Matchup, Milestones, Charities, News & Q&A, Calendar, Join
- Footer links: Privacy, Terms, Admin
- Minimal styling in `app/globals.css`
- Static pages for all required routes
- Home page with a **local-only** vote widget (`components/VoteWidget.tsx`)

When you’re ready to wire auth and data, we’ll swap the placeholders for real Supabase/B2 calls without breaking build.
