
export const metadata = { title: "Terms · Lou Gehrig Fan Club" };
export default function Page(){
  return (
    <section>
      <h1 className="h1">Terms</h1>
      <p className="p">Contact: LouGehrigFanClub@gmail.com. Basic usage terms. (Draft template.)</p>
    </section>
  )
}
