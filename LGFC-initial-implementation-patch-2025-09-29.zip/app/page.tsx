
import VoteWidget from "../components/VoteWidget";

export default function Home(){
  return (
    <section>
      <h1 className="h1">Welcome</h1>
      <p className="p">Celebrating the life of Lou Gehrig and supporting the ALS community.</p>
      <VoteWidget />
      <hr />
      <div className="grid2">
        <a className="card" href="/news"><b>News & Q&A</b><p className="p">Stories, research, and community questions.</p></a>
        <a className="card" href="/milestones"><b>Milestones</b><p className="p">Key moments from Lou’s life and career.</p></a>
      </div>
    </section>
  )
}
