
export const metadata = { title: "Calendar · Lou Gehrig Fan Club" };
export default function Page(){
  return (
    <section>
      <h1 className="h1">Calendar</h1>
      <p className="p">Upcoming events and observances. (Static scaffold.)</p>
    </section>
  )
}
