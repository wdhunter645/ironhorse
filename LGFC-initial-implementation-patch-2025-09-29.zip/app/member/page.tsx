
export const metadata = { title: "Join · Lou Gehrig Fan Club" };
export default function Page(){
  return (
    <section>
      <h1 className="h1">Join</h1>
      <p className="p">Member area placeholder. Auth is not required for this scaffold; we’ll gate once Supabase is configured.</p>
    </section>
  )
}
