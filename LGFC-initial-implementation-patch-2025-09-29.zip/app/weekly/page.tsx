
export const metadata = { title: "Weekly Matchup · Lou Gehrig Fan Club" };
export default function Page(){
  return (
    <section>
      <h1 className="h1">Weekly Matchup</h1>
      <p className="p">Vote on featured photographs each week. This demo page renders without backend dependencies.</p>
    </section>
  )
}
