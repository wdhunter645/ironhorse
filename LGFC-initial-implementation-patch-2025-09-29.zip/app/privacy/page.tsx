
export const metadata = { title: "Privacy · Lou Gehrig Fan Club" };
export default function Page(){
  return (
    <section>
      <h1 className="h1">Privacy</h1>
      <p className="p">Contact: LouGehrigFanClub@gmail.com. We value your privacy. (Draft template.)</p>
    </section>
  )
}
