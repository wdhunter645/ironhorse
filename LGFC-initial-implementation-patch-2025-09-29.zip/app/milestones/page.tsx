
export const metadata = { title: "Milestones · Lou Gehrig Fan Club" };
export default function Page(){
  return (
    <section>
      <h1 className="h1">Milestones</h1>
      <p className="p">A curated timeline of Lou Gehrig’s life and career. (Static scaffold — ready to connect to data.)</p>
    </section>
  )
}
