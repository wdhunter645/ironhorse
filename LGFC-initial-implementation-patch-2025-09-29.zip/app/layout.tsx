
import "./globals.css";
import Header from "../components/Header";
import Footer from "../components/Footer";

export const metadata = {
  title: "Lou Gehrig Fan Club",
  description: "Celebrating Lou Gehrig and supporting the ALS community.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className=\"header\">
          <div className=\"container\">
            <Header />
          </div>
        </div>
        <main className=\"container\">{children}</main>
        <div className=\"footer\">
          <div className=\"container\">
            <Footer />
          </div>
        </div>
      </body>
    </html>
  );
}
