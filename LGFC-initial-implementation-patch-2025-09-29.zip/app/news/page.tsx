
export const metadata = { title: "News & Q&A · Lou Gehrig Fan Club" };
export default function Page(){
  return (
    <section>
      <h1 className="h1">News & Q&A</h1>
      <p className="p">Community updates and member Q&A. (Static scaffold.)</p>
    </section>
  )
}
