
export const metadata = { title: "Admin · Lou Gehrig Fan Club" };
export default function Page(){
  const configured = !!process.env.ADMIN_EMAILS;
  return (
    <section>
      <h1 className="h1">Admin</h1>
      {!configured ? (
        <p className="p">Admin not configured. Set <code>ADMIN_EMAILS</code> to enable gated admin features.</p>
      ) : (
        <p className="p">Admin configured. (Features withheld until auth is wired.)</p>
      )}
    </section>
  )
}
