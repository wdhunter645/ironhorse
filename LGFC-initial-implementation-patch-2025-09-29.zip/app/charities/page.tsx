
export const metadata = { title: "Charities · Lou Gehrig Fan Club" };
export default function Page(){
  return (
    <section>
      <h1 className="h1">Charities</h1>
      <p className="p">We highlight ALS organizations and related causes. (Static scaffold.)</p>
    </section>
  )
}
