# Codex Playbook: Ironhorse Rescue

Follow this exact sequence until CI is green.

1. **Run CI locally**: `npm ci` then `node rescue/scripts/verify_env.mjs`. If missing envs, propose a PR that updates `.env.example` and adds Vercel env instructions (no secrets).
2. **Secret scan**: run `bash rescue/scripts/secret_scan.sh`. If FOUND, propose secret rotation + scrub.
3. **Migrations audit**: run `node rescue/scripts/migration_scan.mjs`. Add idempotent migrations for any missing tables.
4. **Build**: run `bash rescue/scripts/build.sh`. Fix TypeScript/Next config and code until build passes.
5. **Summary**: run `node rescue/scripts/summary.mjs` and paste the summary in the PR.

Acceptance criteria: **rescue workflow green** on PR.
