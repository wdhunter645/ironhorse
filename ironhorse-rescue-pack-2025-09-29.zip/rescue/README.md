# Ironhorse Rescue Pack

This pack gives Codex a **single, deterministic** path to stabilize the repo. No guessing, no back-and-forth.

## What this does
- Runs end‑to‑end sanity checks in CI via **.github/workflows/rescue.yml**
- Verifies required **env vars** and fails fast if any are missing
- Scans for **accidental secrets** committed to the repo
- Audits **Supabase migrations** for required tables
- Prints a crisp **status summary** Codex can paste into the PR

## How to use (one step)
Create a PR that adds this folder and workflow. CI will run automatically.
If you’re pushing straight to `main`, just commit and push.

```bash
# from repo root
cp -r rescue .github tools /  # (already included in this pack)
# CI runs automatically via .github/workflows/rescue.yml
```

## What Codex should do next
Codex must ensure the CI is green by fixing whatever these checks surface:
1. **Missing env vars** → create/update `.env.example` and set Vercel env
2. **Missing tables** → add/repair migrations idempotently
3. **Build errors** → fix Next.js app until `npm run build` passes
4. **Secret leaks** → rotate & scrub, then commit the fix

If any required piece is **blocked by secrets or vendor access**, the workflow will mark **BLOCKED** and print the missing items.

## Output
CI will print a final block like this:

```
IRONHORSE RESCUE SUMMARY
- env:        OK / MISSING / BLOCKED
- secrets:    OK / FOUND
- migrations: OK / MISSING:<table,...>
- build:      OK / FAIL
- next steps: actionable list
```
