#!/usr/bin/env bash
set -euo pipefail

mkdir -p rescue/.state
report="rescue/.state/secrets.txt"
: > "$report"

# Grep patterns for common secrets (shallow heuristic).
# We never print the secret value, only file:line and token type.
grep -RIn --exclude-dir={.git,node_modules,rescue/.state} -E '\b(vck_[A-Za-z0-9_-]{20,})\b' . >> "$report" || true   # Vercel AI keys
grep -RIn --exclude-dir={.git,node_modules,rescue/.state} -E '\b(supabase|SUPABASE)[A-Za-z_]*(key|KEY)\b.*' . >> "$report" || true
grep -RIn --exclude-dir={.git,node_modules,rescue/.state} -E '\b(AKIA[0-9A-Z]{16})\b' . >> "$report" || true        # AWS Access Key ID
grep -RIn --exclude-dir={.git,node_modules,rescue/.state} -E '\b(b2_[a-z0-9]{20,})\b' . >> "$report" || true        # B2 tokens (generic)
grep -RIn --exclude-dir={.git,node_modules,rescue/.state} -E 'BEGIN (RSA|EC) PRIVATE KEY' . >> "$report" || true

if [[ -s "$report" ]];  then
  echo "SECRETS STATUS: FOUND"
  exit 1
else
  echo "SECRETS STATUS: OK"
fi
