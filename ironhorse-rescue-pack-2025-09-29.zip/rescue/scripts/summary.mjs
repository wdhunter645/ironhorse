#!/usr/bin/env node
import fs from 'fs';

function readState(name, def) {
  try { return JSON.parse(fs.readFileSync(`rescue/.state/${name}.json`, 'utf8')); }
  catch { return def; }
}

const env = readState('env', { status: 'UNKNOWN', missing: [] });
let secrets = 'UNKNOWN';
try {
  const s = fs.readFileSync('rescue/.state/secrets.txt', 'utf8');
  secrets = s.trim().length ? 'FOUND' : 'OK';
} catch {
  secrets = 'UNKNOWN';
}

const mig = readState('migrations', { missing: [] });
let build = 'UNKNOWN';
try {
  const log = fs.readFileSync('rescue/.state/build_status.txt', 'utf8').trim();
  build = log || 'UNKNOWN';
} catch {
  // noop
}

console.log('\n==============================');
console.log('IRONHORSE RESCUE SUMMARY');
console.log('------------------------------');
console.log(`env:        ${env.status}${env.missing?.length ? ' -> ' + env.missing.join(', ') : ''}`);
console.log(`secrets:    ${secrets}`);
console.log(`migrations: ${mig.missing?.length ? 'MISSING -> ' + mig.missing.join(', ') : 'OK'}`);
console.log(`build:      ${build}`);

// Next steps
const steps = [];
if (env.status !== 'OK') steps.push('Set missing env vars in Vercel and update .env.example (no secrets in repo).');
if (secrets === 'FOUND') steps.push('Rotate any exposed secrets and scrub the repo history if needed.');
if (mig.missing?.length) steps.push('Add idempotent migrations for missing tables and re-run CI.');
if (build !== 'OK') steps.push('Fix build/lint/test failures until CI green.');

console.log('next steps: ', steps.length ? steps.join(' | ') : 'All good.');
console.log('==============================\n');
