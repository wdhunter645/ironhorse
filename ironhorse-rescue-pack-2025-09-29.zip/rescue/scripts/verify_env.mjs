#!/usr/bin/env node
/**
 * Strict env verification without printing secrets.
 * Exits non-zero if required vars are missing.
 */
const required = [
  'NEXT_PUBLIC_SITE_URL',
  'NEXT_PUBLIC_SUPABASE_URL',
  'NEXT_PUBLIC_SUPABASE_ANON_KEY',
  // Project policy allows this in prod; if omitted we mark BLOCKED for DB-level checks
  'SUPABASE_SERVICE_ROLE_KEY',
  'ADMIN_EMAILS',
  'B2_KEY_ID',
  'B2_APP_KEY',
  'B2_BUCKET',
  'B2_ENDPOINT',
  'PUBLIC_B2_BASE_URL',
];

const missing = required.filter(k => !process.env[k] || String(process.env[k]).trim() === '');

let status = 'OK';
if (missing.length === required.length) status = 'BLOCKED';
else if (missing.length > 0) status = 'MISSING';

// Write status file for summary step
import fs from 'fs';
fs.mkdirSync('rescue/.state', { recursive: true });
fs.writeFileSync('rescue/.state/env.json', JSON.stringify({ status, missing }, null, 2));

if (status !== 'OK') {
  console.log(`ENV STATUS: ${status}`);
  if (missing.length) console.log('Missing:', missing.join(', '));
  process.exit( (status === 'BLOCKED') ? 2 : 1 );
} else {
  console.log('ENV STATUS: OK');
}
