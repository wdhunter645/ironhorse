#!/usr/bin/env bash
set -euo pipefail
status="OK"
if npm run build --if-present; then
  echo "OK" > rescue/.state/build_status.txt
else
  echo "FAIL" > rescue/.state/build_status.txt
  exit 1
fi
