#!/usr/bin/env node
/**
 * Static audit of Supabase migrations to ensure core tables exist.
 * We don't hit the DB; we only inspect migration SQL.
 */
import fs from 'fs';
import path from 'path';

const requiredTables = [
  'media_assets',
  'quotes',
  'photos',
  'matchups',
  'votes',
  'charities',
  'milestones',
  'posts',
  'events'
];

function allSqlFiles(dir) {
  const results = [];
  if (!fs.existsSync(dir)) return results;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) results.push(...allSqlFiles(p));
    else if (e.isFile() && p.endsWith('.sql')) results.push(p);
  }
  return results;
}

const sqlFiles = allSqlFiles('supabase/migrations');
const sql = sqlFiles.map(f => fs.readFileSync(f, 'utf8').toLowerCase()).join('\n');

const missing = requiredTables.filter(t => !sql.includes(`create table if not exists public.${t}`) && !sql.includes(`create table public.${t}`));

fs.mkdirSync('rescue/.state', { recursive: true });
fs.writeFileSync('rescue/.state/migrations.json', JSON.stringify({ files: sqlFiles.length, missing }, null, 2));

if (missing.length) {
  console.log('MIGRATIONS STATUS: MISSING ->', missing.join(', '));
  process.exit(1);
} else {
  console.log('MIGRATIONS STATUS: OK');
}
