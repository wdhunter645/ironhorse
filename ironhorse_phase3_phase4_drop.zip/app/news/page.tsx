export default function Page() { return <div className="prose"><h1>News</h1><p>Coming soon.</p></div>; }
