export default function Page() { return <div className="prose"><h1>Calendar</h1><p>Coming soon.</p></div>; }
