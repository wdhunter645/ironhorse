export default function Page() { return <div className="prose"><h1>Milestones</h1><p>Coming soon.</p></div>; }
