export default function Page() { return <div className="prose"><h1>Q&A / FAQ</h1><p>Coming soon.</p></div>; }
